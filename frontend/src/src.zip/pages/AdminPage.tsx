import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'sonner'

import {
  ApiError,
  createAdminUser,
  createAdminVehicle,
  deleteAdminUser,
  deleteAdminVehicle,
  fetchAdminUsers,
  fetchAdminVehicles,
  updateAdminUser,
  updateAdminVehicle,
} from '../api/client'
import { clearSession, readSession } from '../auth/session'
import { CITY_OPTIONS, findCity } from '../cities'
import type {
  AdminUserInput,
  AdminVehicle,
  AdminVehicleInput,
  Role,
  Session,
  User,
  VehicleType,
} from '../types'
import { AppHeader } from '../components/AppHeader'
import { CitySearchSelect } from '../components/CitySearchSelect'
import { ConfirmDialog } from '../components/ConfirmDialog'
import { IconMap, IconPlus } from '../components/icons'
import { Select } from '../components/Select'

type Tab = 'users' | 'vehicles'

interface UserForm {
  id: number | null
  name: string
  email: string
  password: string
  role: Role
  operating_city: string
}

interface VehicleForm {
  id: number | null
  name: string
  plate: string
  type: VehicleType
  operating_city: string
  home_lat: string
  home_lng: string
  driver_id: string
  status: 'available' | 'offline'
}

type PendingDelete =
  | { kind: 'user'; user: User }
  | { kind: 'vehicle'; vehicle: AdminVehicle }

const ROLE_LABEL: Record<Role, string> = {
  admin: 'Admin',
  dispatcher: 'Dispatcher',
  driver: 'Driver',
}

const TYPE_LABEL: Record<VehicleType, string> = {
  ambulance: 'Ambulans',
  fire: 'Damkar',
  police: 'Patroli',
}

const STATUS_LABEL: Record<string, string> = {
  available: 'Tersedia',
  assigned: 'Ditugaskan',
  en_route: 'Menuju lokasi',
  on_scene: 'Di lokasi',
  offline: 'Offline',
}

function emptyUserForm(): UserForm {
  return {
    id: null,
    name: '',
    email: '',
    password: '',
    role: 'dispatcher',
    operating_city: '',
  }
}

function emptyVehicleForm(): VehicleForm {
  const city = CITY_OPTIONS[0]
  return {
    id: null,
    name: '',
    plate: '',
    type: 'ambulance',
    operating_city: city.name,
    home_lat: String(city.center[0]),
    home_lng: String(city.center[1]),
    driver_id: '',
    status: 'available',
  }
}

function errorText(err: unknown, fallback: string): string {
  return err instanceof ApiError ? err.message : fallback
}

function deleteDialogContent(pending: PendingDelete | null): { title: string; description: string } {
  if (!pending) return { title: '', description: '' }
  if (pending.kind === 'user') {
    return {
      title: `Hapus akun ${pending.user.name}?`,
      description: `Akun ${pending.user.email} tidak bisa dipulihkan. Jika akun masih dipakai data insiden atau tugas, server akan menolak penghapusan.`,
    }
  }
  return {
    title: `Hapus kendaraan ${pending.vehicle.name}?`,
    description: `Kendaraan ${pending.vehicle.plate} akan dihapus beserta riwayat tugas non-aktifnya. Unit yang sedang bertugas tidak bisa dihapus.`,
  }
}

export function AdminPage() {
  const navigate = useNavigate()
  const [session] = useState<Session | null>(() => readSession())
  const [tab, setTab] = useState<Tab>('users')
  const [users, setUsers] = useState<User[]>([])
  const [vehicles, setVehicles] = useState<AdminVehicle[]>([])
  const [cityFilter, setCityFilter] = useState('')
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState<string | null>(null)

  const [userForm, setUserForm] = useState<UserForm | null>(null)
  const [showFormPassword, setShowFormPassword] = useState(false)
  const [vehicleForm, setVehicleForm] = useState<VehicleForm | null>(null)
  const [formError, setFormError] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [pendingDelete, setPendingDelete] = useState<PendingDelete | null>(null)
  const [deleting, setDeleting] = useState(false)

  const handleUnauthorized = useCallback(() => {
    clearSession()
    navigate('/login', { replace: true })
  }, [navigate])

  const loadAll = useCallback(async () => {
    if (!session) return
    setLoading(true)
    setLoadError(null)
    try {
      const [nextUsers, nextVehicles] = await Promise.all([
        fetchAdminUsers(session.token),
        fetchAdminVehicles(session.token, cityFilter),
      ])
      setUsers(nextUsers)
      setVehicles(nextVehicles)
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        handleUnauthorized()
        return
      }
      if (err instanceof ApiError && err.status === 403) {
        setLoadError('Halaman ini hanya bisa dibuka oleh admin.')
        return
      }
      setLoadError(errorText(err, 'Data belum bisa dimuat. Segarkan halaman atau coba beberapa saat lagi.'))
    } finally {
      setLoading(false)
    }
  }, [session, cityFilter, handleUnauthorized])

  useEffect(() => {
    // oxlint-disable-next-line react/set-state-in-effect -- memuat data admin dari API
    void loadAll()
  }, [loadAll])

  const drivers = useMemo(() => users.filter((user) => user.role === 'driver'), [users])
  const cityDrivers = useMemo(() => {
    if (!vehicleForm) return []
    return drivers.filter((driver) => driver.operating_city === vehicleForm.operating_city)
  }, [drivers, vehicleForm])

  function handleLogout() {
    clearSession()
    navigate('/login', { replace: true })
  }

  function openCreateUser() {
    setTab('users')
    setUserForm(emptyUserForm())
    setFormError(null)
  }

  function openEditUser(user: User) {
    setTab('users')
    setUserForm({
      id: user.id,
      name: user.name,
      email: user.email,
      password: '',
      role: user.role,
      operating_city: user.operating_city ?? '',
    })
    setFormError(null)
  }

  function openCreateVehicle() {
    setTab('vehicles')
    setVehicleForm(emptyVehicleForm())
    setFormError(null)
  }

  function openEditVehicle(vehicle: AdminVehicle) {
    setTab('vehicles')
    setVehicleForm({
      id: vehicle.id,
      name: vehicle.name,
      plate: vehicle.plate,
      type: vehicle.type,
      operating_city: vehicle.operating_city ?? CITY_OPTIONS[0].name,
      home_lat: String(vehicle.home_lat),
      home_lng: String(vehicle.home_lng),
      driver_id: vehicle.driver_id ? String(vehicle.driver_id) : '',
      status: vehicle.status === 'offline' ? 'offline' : 'available',
    })
    setFormError(null)
  }

  function updateUserField<K extends keyof UserForm>(field: K, value: UserForm[K]) {
    setUserForm((previous) => {
      if (!previous) return previous
      const next = { ...previous, [field]: value }
      if (field === 'role') {
        if (value === 'admin') next.operating_city = ''
        if (value === 'driver' && !next.operating_city) {
          next.operating_city = CITY_OPTIONS[0].name
        }
      }
      return next
    })
  }

  function updateVehicleField<K extends keyof VehicleForm>(field: K, value: VehicleForm[K]) {
    setVehicleForm((previous) => {
      if (!previous) return previous
      const next = { ...previous, [field]: value }
      if (field === 'operating_city') {
        const city = findCity(String(value))
        if (city) {
          next.home_lat = String(city.center[0])
          next.home_lng = String(city.center[1])
        }
        const driverStillValid = drivers.some(
          (driver) => String(driver.id) === next.driver_id && driver.operating_city === value,
        )
        if (!driverStillValid) next.driver_id = ''
      }
      return next
    })
  }

  async function submitUser(event: FormEvent) {
    event.preventDefault()
    if (!session || !userForm) return
    setSaving(true)
    setFormError(null)

    const input: AdminUserInput = {
      name: userForm.name.trim(),
      email: userForm.email.trim().toLowerCase(),
      password: userForm.password,
      role: userForm.role,
      operating_city: userForm.role === 'admin' ? '' : userForm.operating_city,
    }

    try {
      if (userForm.id == null) {
        await createAdminUser(session.token, input)
        toast.success('Akun baru berhasil dibuat', { description: input.name })
      } else {
        await updateAdminUser(session.token, userForm.id, input)
        toast.success('Perubahan akun tersimpan', { description: input.name })
      }
      setUserForm(null)
      await loadAll()
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        handleUnauthorized()
        return
      }
      setFormError(errorText(err, 'Akun belum tersimpan. Periksa isian lalu coba lagi.'))
    } finally {
      setSaving(false)
    }
  }

  async function submitVehicle(event: FormEvent) {
    event.preventDefault()
    if (!session || !vehicleForm) return
    setSaving(true)
    setFormError(null)

    const input: AdminVehicleInput = {
      name: vehicleForm.name.trim(),
      plate: vehicleForm.plate.trim(),
      type: vehicleForm.type,
      operating_city: vehicleForm.operating_city,
      home_lat: Number(vehicleForm.home_lat),
      home_lng: Number(vehicleForm.home_lng),
      driver_id: vehicleForm.driver_id ? Number(vehicleForm.driver_id) : null,
    }

    const current = vehicleForm.id == null ? null : vehicles.find((item) => item.id === vehicleForm.id)
    if (current && (current.status === 'available' || current.status === 'offline')) {
      input.status = vehicleForm.status
    }

    try {
      if (vehicleForm.id == null) {
        await createAdminVehicle(session.token, input)
        toast.success('Kendaraan baru berhasil ditambahkan', { description: input.name })
      } else {
        await updateAdminVehicle(session.token, vehicleForm.id, input)
        toast.success('Perubahan kendaraan tersimpan', { description: input.name })
      }
      setVehicleForm(null)
      await loadAll()
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        handleUnauthorized()
        return
      }
      setFormError(errorText(err, 'Kendaraan belum tersimpan. Periksa isian lalu coba lagi.'))
    } finally {
      setSaving(false)
    }
  }

  async function removeUser(user: User): Promise<boolean> {
    if (!session) return false
    try {
      await deleteAdminUser(session.token, user.id)
      toast.success(`Akun ${user.name} berhasil dihapus`)
      if (userForm?.id === user.id) setUserForm(null)
      await loadAll()
      return true
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        handleUnauthorized()
        return false
      }
      toast.error('Akun belum bisa dihapus', {
        description: errorText(err, 'Akun masih terhubung dengan data lain atau koneksi bermasalah.'),
      })
      return false
    }
  }

  async function removeVehicle(vehicle: AdminVehicle): Promise<boolean> {
    if (!session) return false
    try {
      await deleteAdminVehicle(session.token, vehicle.id)
      toast.success(`Kendaraan ${vehicle.name} berhasil dihapus`)
      if (vehicleForm?.id === vehicle.id) setVehicleForm(null)
      await loadAll()
      return true
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        handleUnauthorized()
        return false
      }
      toast.error('Kendaraan belum bisa dihapus', {
        description: errorText(err, 'Unit mungkin sedang menjalani tugas.'),
      })
      return false
    }
  }

  async function handleConfirmDelete() {
    if (!pendingDelete) return
    setDeleting(true)
    const ok =
      pendingDelete.kind === 'user'
        ? await removeUser(pendingDelete.user)
        : await removeVehicle(pendingDelete.vehicle)
    setDeleting(false)
    if (ok) setPendingDelete(null)
  }

  const deleteCopy = deleteDialogContent(pendingDelete)

  if (!session) return null

  return (
    <div className="admin-shell">
      <AppHeader subtitle="Panel admin" session={session} onLogout={handleLogout}>
        <Link className="button button-ghost" to="/map">
          <IconMap size={16} />
          Buka peta
        </Link>
      </AppHeader>

      <main className="admin-main">
        <div className="admin-heading">
          <h1>Akun dan armada</h1>
          <p className="muted">
            Tambah petugas, tetapkan driver ke kendaraan, dan atur kota tugas. Perubahan langsung terbaca di peta dispatcher.
          </p>
        </div>

        <dl className="admin-stats" aria-label="Ringkasan data">
          <div className="admin-stat">
            <dt>Akun terdaftar</dt>
            <dd>{users.length}</dd>
          </div>
          <div className="admin-stat">
            <dt>Driver</dt>
            <dd>{users.filter((item) => item.role === 'driver').length}</dd>
          </div>
          <div className="admin-stat">
            <dt>Kendaraan</dt>
            <dd>{vehicles.length}</dd>
          </div>
          <div className="admin-stat admin-stat--success">
            <dt>Siap bertugas</dt>
            <dd>{vehicles.filter((item) => item.status === 'available').length}</dd>
          </div>
        </dl>

        {loadError ? (
          <div className="admin-alert admin-alert--error" role="alert">
            {loadError}
          </div>
        ) : null}
        {formError && !userForm && !vehicleForm ? (
          <div className="admin-alert admin-alert--error" role="alert">
            {formError}
          </div>
        ) : null}

        <div className={`admin-layout ${userForm || vehicleForm ? 'admin-layout--form' : ''}`}>
          <section className="admin-card">
            <div className="admin-card-head">
              <div className="admin-tabs" role="tablist" aria-label="Pilih data">
                <button
                  className={`admin-tab ${tab === 'users' ? 'admin-tab--active' : ''}`}
                  type="button"
                  role="tab"
                  aria-selected={tab === 'users'}
                  onClick={() => setTab('users')}
                >
                  Akun <span>{users.length}</span>
                </button>
                <button
                  className={`admin-tab ${tab === 'vehicles' ? 'admin-tab--active' : ''}`}
                  type="button"
                  role="tab"
                  aria-selected={tab === 'vehicles'}
                  onClick={() => setTab('vehicles')}
                >
                  Kendaraan <span>{vehicles.length}</span>
                </button>
              </div>

              {tab === 'users' ? (
                <button className="button button-primary" type="button" onClick={openCreateUser}>
                  <IconPlus size={16} />
                  Tambah akun
                </button>
              ) : (
                <div className="admin-card-actions">
                  <Select
                    variant="filter"
                    ariaLabel="Filter kota kendaraan"
                    value={cityFilter}
                    onChange={setCityFilter}
                    options={[
                      { value: '', label: 'Semua kota' },
                      ...CITY_OPTIONS.map((city) => ({ value: city.name, label: city.name })),
                    ]}
                  />
                  <button className="button button-primary" type="button" onClick={openCreateVehicle}>
                    <IconPlus size={16} />
                    Tambah kendaraan
                  </button>
                </div>
              )}
            </div>

            {loading ? (
              <div className="admin-loading">
                <span className="spinner" aria-hidden="true" />
                Memuat data…
              </div>
            ) : tab === 'users' && users.length === 0 ? (
              <p className="admin-empty">Belum ada akun. Tambahkan akun pertama dengan tombol di atas.</p>
            ) : tab === 'vehicles' && vehicles.length === 0 ? (
              <p className="admin-empty">
                {cityFilter ? `Belum ada kendaraan di ${cityFilter}.` : 'Belum ada kendaraan terdaftar.'}
              </p>
            ) : tab === 'users' ? (
              <div className="admin-table-wrap">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>Nama</th>
                      <th>Email</th>
                      <th>Peran</th>
                      <th>Kota</th>
                      <th className="admin-col-actions">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((user) => (
                      <tr key={user.id}>
                        <td data-label="Nama">
                          <span className="cell-user">
                            <span className="avatar avatar--sm" aria-hidden="true">
                              {user.name.charAt(0).toUpperCase()}
                            </span>
                            {user.name}
                          </span>
                        </td>
                        <td data-label="Email" className="admin-mono">{user.email}</td>
                        <td data-label="Peran">
                          <span className={`admin-badge admin-badge--${user.role}`}>
                            {ROLE_LABEL[user.role]}
                          </span>
                        </td>
                        <td data-label="Kota">{user.operating_city ?? 'Semua kota'}</td>
                        <td className="admin-col-actions">
                          <button className="admin-link" type="button" onClick={() => openEditUser(user)}>
                            Edit
                          </button>
                          <button
                            className="admin-link admin-link--danger"
                            type="button"
                            onClick={() => setPendingDelete({ kind: 'user', user })}
                          >
                            Hapus
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="admin-table-wrap">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>Nama</th>
                      <th>Nomor polisi</th>
                      <th>Jenis</th>
                      <th>Kota</th>
                      <th>Status</th>
                      <th>Driver</th>
                      <th className="admin-col-actions">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {vehicles.map((vehicle) => (
                      <tr key={vehicle.id}>
                        <td data-label="Nama">{vehicle.name}</td>
                        <td data-label="No. polisi" className="admin-mono">{vehicle.plate}</td>
                        <td data-label="Jenis">{TYPE_LABEL[vehicle.type]}</td>
                        <td data-label="Kota">{vehicle.operating_city ?? '—'}</td>
                        <td data-label="Status">
                          <span className={`admin-badge admin-badge--status-${vehicle.status}`}>
                            {STATUS_LABEL[vehicle.status] ?? vehicle.status}
                          </span>
                        </td>
                        <td data-label="Driver">{vehicle.driver_name ?? 'Belum ada driver'}</td>
                        <td className="admin-col-actions">
                          <button
                            className="admin-link"
                            type="button"
                            onClick={() => openEditVehicle(vehicle)}
                          >
                            Edit
                          </button>
                          <button
                            className="admin-link admin-link--danger"
                            type="button"
                            onClick={() => setPendingDelete({ kind: 'vehicle', vehicle })}
                          >
                            Hapus
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>

          {userForm || vehicleForm ? (
            <div
              className="admin-backdrop"
              aria-hidden="true"
              onClick={() => {
                setUserForm(null)
                setVehicleForm(null)
                setFormError(null)
              }}
            />
          ) : null}

          {userForm ? (
            <aside className="admin-form-card" aria-label="Form akun">
              <div className="admin-form-head">
                <div>
                  <h2>{userForm.id == null ? 'Akun baru' : 'Ubah akun'}</h2>
                  {userForm.id != null ? <p className="panel-sub">{userForm.name}</p> : null}
                </div>
                <button
                  className="button button-ghost admin-close"
                  type="button"
                  onClick={() => {
                    setUserForm(null)
                    setFormError(null)
                  }}
                >
                  Tutup
                </button>
              </div>

              <form className="admin-form" onSubmit={submitUser}>
                <label className="field">
                  Nama
                  <input
                    value={userForm.name}
                    onChange={(event) => updateUserField('name', event.target.value)}
                    required
                  />
                </label>
                <label className="field">
                  Email
                  <input
                    type="email"
                    value={userForm.email}
                    onChange={(event) => updateUserField('email', event.target.value)}
                    disabled={userForm.id != null}
                    required
                  />
                  {userForm.id != null ? <span className="field-hint">Email dipakai untuk masuk, jadi tidak bisa diganti.</span> : null}
                </label>
                <label className="field">
                  {userForm.id == null ? 'Password' : 'Password baru'}
                  <span className="field-password">
                    <input
                      type={showFormPassword ? 'text' : 'password'}
                      value={userForm.password}
                      onChange={(event) => updateUserField('password', event.target.value)}
                      placeholder={userForm.id == null ? 'Minimal 6 karakter' : 'Kosongkan jika tidak diganti'}
                      autoComplete="new-password"
                      required={userForm.id == null}
                    />
                    <button
                      type="button"
                      className="field-password-toggle"
                      onClick={() => setShowFormPassword((value) => !value)}
                      aria-label={showFormPassword ? 'Sembunyikan password' : 'Tampilkan password'}
                      aria-pressed={showFormPassword}
                    >
                      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z" />
                        <circle cx="12" cy="12" r="3" />
                        {showFormPassword ? <path d="M4 4l16 16" /> : null}
                      </svg>
                    </button>
                  </span>
                </label>
                <div className="form-grid">
                  <label className="field">
                    Peran
                    <Select
                      value={userForm.role}
                      onChange={(value) => updateUserField('role', value as Role)}
                      options={[
                        { value: 'dispatcher', label: 'Dispatcher' },
                        { value: 'driver', label: 'Driver' },
                        { value: 'admin', label: 'Admin' },
                      ]}
                    />
                  </label>
                  <label className="field">
                    Kota operasi
                    <CitySearchSelect
                      mode="province-first"
                      value={userForm.operating_city}
                      onChange={(value) => updateUserField('operating_city', value)}
                      disabled={userForm.role === 'admin'}
                      variant="field"
                      showAllOption={userForm.role !== 'driver'}
                      allLabel="Semua kota"
                      searchPlaceholder="Cari kota atau provinsi…"
                    />
                    {userForm.role === 'admin' ? (
                      <span className="field-hint">Admin bisa mengakses semua kota.</span>
                    ) : null}
                  </label>
                </div>

                {formError ? (
                  <p className="form-error" role="alert">
                    {formError}
                  </p>
                ) : null}

                <div className="form-actions">
                  <button className="button button-primary" type="submit" disabled={saving}>
                    {saving ? 'Menyimpan…' : 'Simpan akun'}
                  </button>
                </div>
              </form>
            </aside>
          ) : null}

          {vehicleForm ? (
            <aside className="admin-form-card" aria-label="Form kendaraan">
              <div className="admin-form-head">
                <div>
                  <h2>{vehicleForm.id == null ? 'Kendaraan baru' : 'Ubah kendaraan'}</h2>
                  {vehicleForm.id != null ? <p className="panel-sub">{vehicleForm.name}</p> : null}
                </div>
                <button
                  className="button button-ghost admin-close"
                  type="button"
                  onClick={() => {
                    setVehicleForm(null)
                    setFormError(null)
                  }}
                >
                  Tutup
                </button>
              </div>

              <form className="admin-form" onSubmit={submitVehicle}>
                <label className="field">
                  Nama kendaraan
                  <input
                    value={vehicleForm.name}
                    onChange={(event) => updateVehicleField('name', event.target.value)}
                    required
                  />
                </label>
                <div className="form-grid">
                  <label className="field">
                    Nomor polisi
                    <input
                      value={vehicleForm.plate}
                      onChange={(event) => updateVehicleField('plate', event.target.value)}
                      required
                    />
                  </label>
                  <label className="field">
                    Jenis
                    <Select
                      value={vehicleForm.type}
                      onChange={(value) => updateVehicleField('type', value as VehicleType)}
                      options={[
                        { value: 'ambulance', label: 'Ambulans' },
                        { value: 'fire', label: 'Damkar' },
                        { value: 'police', label: 'Patroli' },
                      ]}
                    />
                  </label>
                </div>
                <div className="form-grid">
                  <label className="field">
                    Kota operasi
                    <CitySearchSelect
                      mode="province-first"
                      value={vehicleForm.operating_city}
                      onChange={(value) => updateVehicleField('operating_city', value)}
                      variant="field"
                      showAllOption={false}
                      searchPlaceholder="Cari kota atau provinsi…"
                    />
                  </label>
                  <label className="field">
                    Driver
                    <Select
                      value={vehicleForm.driver_id}
                      onChange={(value) => updateVehicleField('driver_id', value)}
                      options={[
                        { value: '', label: 'Tanpa driver' },
                        ...cityDrivers.map((driver) => ({ value: String(driver.id), label: driver.name })),
                      ]}
                    />
                  </label>
                </div>
                <div className="form-grid">
                  <label className="field">
                    Lintang pangkalan
                    <input
                      type="number"
                      step="0.000001"
                      value={vehicleForm.home_lat}
                      onChange={(event) => updateVehicleField('home_lat', event.target.value)}
                      required
                    />
                  </label>
                  <label className="field">
                    Bujur pangkalan
                    <input
                      type="number"
                      step="0.000001"
                      value={vehicleForm.home_lng}
                      onChange={(event) => updateVehicleField('home_lng', event.target.value)}
                      required
                    />
                  </label>
                </div>
                {vehicleForm.id != null ? (
                  <label className="field">
                    Kesiapan unit
                    <Select
                      value={vehicleForm.status}
                      onChange={(value) => updateVehicleField('status', value as 'available' | 'offline')}
                      disabled={
                        vehicles.find((item) => item.id === vehicleForm.id)?.status !== 'available' &&
                        vehicles.find((item) => item.id === vehicleForm.id)?.status !== 'offline'
                      }
                      options={[
                        { value: 'available', label: 'Tersedia' },
                        { value: 'offline', label: 'Offline' },
                      ]}
                    />
                  </label>
                ) : null}

                {formError ? (
                  <p className="form-error" role="alert">
                    {formError}
                  </p>
                ) : null}

                <div className="form-actions">
                  <button className="button button-primary" type="submit" disabled={saving}>
                    {saving ? 'Menyimpan…' : 'Simpan kendaraan'}
                  </button>
                </div>
              </form>
            </aside>
          ) : null}
        </div>
      </main>

      <ConfirmDialog
        open={pendingDelete !== null}
        tone="danger"
        title={deleteCopy.title}
        description={deleteCopy.description}
        confirmLabel="Hapus"
        cancelLabel="Batal"
        busy={deleting}
        onConfirm={() => void handleConfirmDelete()}
        onCancel={() => {
          if (!deleting) setPendingDelete(null)
        }}
      />
    </div>
  )
}
